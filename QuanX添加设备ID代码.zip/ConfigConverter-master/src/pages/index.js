import styles from './index.css';

export default function() {
  return (
    <div className={styles.normal}>
        <div>The home page is developing.</div>
        <div>
          <a href="https://github.com/ImSingee/ConfigConverter">
            Move to Github
          </a>
        </div>
    </div>
  );
}
